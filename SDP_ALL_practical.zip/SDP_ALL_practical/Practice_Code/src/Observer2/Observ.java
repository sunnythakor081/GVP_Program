package Observer2;

public interface Observ {
    void update(String notify);
}
