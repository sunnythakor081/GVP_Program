package Strategy;

public class Nonpoisonous implements BiteBehv{
    @Override
    public String bite() {
        return "this snak is Nonpoisonous";
    }
}
