package Strategy;

public interface BiteBehv {
    String bite();
}
