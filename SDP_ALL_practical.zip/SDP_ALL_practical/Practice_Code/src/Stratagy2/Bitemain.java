package Stratagy2;

public class Bitemain {
    public static void main(String[] args) {
        Snak py = new kingcobra();

        System.out.println(py.display());
        System.out.println(py.setbite());
    }
}
