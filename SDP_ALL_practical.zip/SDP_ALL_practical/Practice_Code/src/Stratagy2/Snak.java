package Stratagy2;

public interface Snak {
    public String display();
    public String setbite();
    public void permonce(Bitebihv bitebihv);
}
