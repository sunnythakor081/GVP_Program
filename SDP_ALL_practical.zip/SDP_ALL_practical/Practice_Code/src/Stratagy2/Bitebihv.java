package Stratagy2;

public interface Bitebihv {
    String bite();
}
