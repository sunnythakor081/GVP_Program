package Stratagy2;

public class Pois implements Bitebihv{
    @Override
    public String bite() {
        return "";
    }
}
