package myshollw;

public interface IMyGame extends Cloneable{

    IMyGame clone();
    void ShowAttribute();

}
