package Decorator.PizzaToppingsDecorator;

public interface Pizza {
    String getdescripter();
    double getcost();

}

