package Decorator.TextEditor;

public interface Text {
    String setContent();
}
