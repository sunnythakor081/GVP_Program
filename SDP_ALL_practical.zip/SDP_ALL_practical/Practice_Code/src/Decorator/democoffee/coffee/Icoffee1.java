package Decorator.democoffee.coffee;

public interface Icoffee1 {
    String discreapsion();
    Double cost();
}
