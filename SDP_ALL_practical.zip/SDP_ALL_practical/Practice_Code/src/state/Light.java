package state;

public interface Light {
    void lightState(State state);
}
