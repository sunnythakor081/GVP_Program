package ShallowGameGOF;

public interface IGame extends Cloneable {
    IGame clone();
    void showAttributes();
}