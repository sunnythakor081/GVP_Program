package Proxy;

public interface I_cal {

    double sumofnum();
}
