package Proxy;

public class P implements I_cal{
    @Override
    public double sumofnum() {
        int a  = 10;
        int b = 20;
        int sum=a+b;
        return sum;
    }
}
