package Facad;

public class Samsung implements MobileShop {
    @Override
    public void mobilename() {

        System.out.println("samsung s24 ultra");
    }

    @Override
    public void price() {

        System.out.println("1,23,000");

    }
}
