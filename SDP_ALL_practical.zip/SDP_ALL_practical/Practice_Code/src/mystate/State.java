package mystate;

public interface State {
    void pressButtern(Fan fan);
}
