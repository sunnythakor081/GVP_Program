package AbStract_factory.hospitalABfactory;

public class ManipalHospitalNeurology implements Neurology{
    @Override
    public String createNeurology() {
        return "ManipalHospital Neurology";
    }
}
