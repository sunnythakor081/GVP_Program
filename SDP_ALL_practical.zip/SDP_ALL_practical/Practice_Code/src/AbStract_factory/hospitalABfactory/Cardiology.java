package AbStract_factory.hospitalABfactory;

public interface Cardiology {
    public String createCardiology();
}
