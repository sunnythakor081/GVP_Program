package AbStract_factory.hospitalABfactory;

public class ApolloHospitalsCardiology implements Cardiology{
    @Override
    public String createCardiology() {
        return "ApolloHospitals Cardiology";
    }
}
