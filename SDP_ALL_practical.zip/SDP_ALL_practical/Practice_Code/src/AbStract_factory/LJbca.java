package AbStract_factory;

public class LJbca implements Bca{
    @Override
    public String createBca() {
        return "LJ BCA";
    }
}
