package AbStract_factory;

public class PARULBca implements Bca {

    @Override
    public String createBca() {
        return "PARUL BCA";
    }
}

