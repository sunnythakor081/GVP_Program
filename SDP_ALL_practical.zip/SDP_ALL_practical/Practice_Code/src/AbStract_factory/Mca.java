package AbStract_factory;

public interface Mca {
    public String createMca();
}
