package AbStract_factory;

public class GVPmca implements Mca {
    @Override
    public String createMca() {
        return "create GVP MCA";
    }
}
