package AbStract_factory;

public class GVPbca implements Bca{
    @Override
    public String createBca()
    {
        return "GVP BCA";
    }
}
