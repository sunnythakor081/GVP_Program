package Observer_Pattern.ob3;

public interface Observnewz {
    void update(String news);
}
