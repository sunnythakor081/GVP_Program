package Observer_Pattern.ob3;

public interface SubjectOb {
    void attech(Observnewz o);
    void dettech(Observnewz o);
    void notifi();
}
