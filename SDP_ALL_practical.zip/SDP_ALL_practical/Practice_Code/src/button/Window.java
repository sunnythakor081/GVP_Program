package button;

public class Window extends Abstractcom {
    @Override
    public String radio() {
        return "window radio";
    }

    @Override
    public String button() {
        return "window button";
    }

    @Override
    public String check() {
        return "window check";
    }
}
