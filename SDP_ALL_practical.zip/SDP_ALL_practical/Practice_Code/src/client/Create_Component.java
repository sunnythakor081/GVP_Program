package client;

public abstract class Create_Component {

    public abstract String radio();
    public abstract String button();
    public abstract String checkbox();

}
