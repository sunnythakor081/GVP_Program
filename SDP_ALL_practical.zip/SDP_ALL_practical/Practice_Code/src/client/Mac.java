package client;

public class Mac extends Create_Component {
    @Override
    public String radio() {
        return "Mac radiobutton";
    }

    @Override
    public String button() {
        return "Mac button";
    }

    @Override
    public String checkbox() {
        return "Mac checkbox";
    }
}
