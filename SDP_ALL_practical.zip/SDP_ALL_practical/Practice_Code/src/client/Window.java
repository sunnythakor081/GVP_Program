package client;

public class Window extends Create_Component {

    @Override
    public String radio() {
        //System.out.println("window radiobutton");
        return "window radio";
    }

    @Override
    public String button() {

        return "window button";
    }

    @Override
    public String checkbox() {
        return "window checkbox";
    }
}
