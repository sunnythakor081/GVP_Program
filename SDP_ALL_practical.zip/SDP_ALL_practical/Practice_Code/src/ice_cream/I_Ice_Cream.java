package ice_cream;

public interface I_Ice_Cream {

    void getcost();
    double getDescription();
}
