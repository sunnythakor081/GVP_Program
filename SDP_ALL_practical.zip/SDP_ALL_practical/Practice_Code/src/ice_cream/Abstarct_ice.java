package ice_cream;

public abstract class Abstarct_ice implements I_Ice_Cream {

    private I_Ice_Cream abstractice;

    public Abstarct_ice(I_Ice_Cream bice_cream){

    }


}
