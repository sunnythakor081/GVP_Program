package It;

public interface Employ {
    public int salary();
    public String name();
    public String department();

}
