package OsComponent;

public class WindowCheckButton implements CheckButton{
    @Override
    public String createcheckButton() {
        return "create Window CheckButton";
    }
}
