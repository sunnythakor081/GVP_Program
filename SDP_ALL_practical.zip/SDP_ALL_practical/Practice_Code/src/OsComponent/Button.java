package OsComponent;

public interface Button {
    public  String creactebutton();


}
