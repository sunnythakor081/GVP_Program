package OsComponent;

public class WindowRadio implements RadioButton{
    @Override
    public String createradioButton() {
        return "create Window RadioButton";
    }
}
