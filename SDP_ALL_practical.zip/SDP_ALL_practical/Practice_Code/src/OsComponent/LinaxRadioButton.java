package OsComponent;

public class LinaxRadioButton implements RadioButton{
    @Override
    public String createradioButton() {
        return "Craete Linax RadioButton";
    }
}
