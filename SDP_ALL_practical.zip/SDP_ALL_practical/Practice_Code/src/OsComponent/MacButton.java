package OsComponent;

public class MacButton implements Button{
    @Override
    public String creactebutton() {
        return "Craete Mac Button";
    }
}
