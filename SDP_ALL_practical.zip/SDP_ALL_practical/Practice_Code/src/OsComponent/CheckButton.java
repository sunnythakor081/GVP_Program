package OsComponent;

public interface CheckButton{
    public String createcheckButton();
}
