package OsComponent;

public interface RadioButton{
    public String createradioButton();
}
