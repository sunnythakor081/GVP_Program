package OsComponent;

public class WindowButton implements Button {
    @Override
    public String creactebutton() {
        return "create window button";
    }
}
