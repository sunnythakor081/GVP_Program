package OsComponent;

public class MacCheckButton implements CheckButton{
    @Override
    public String createcheckButton() {
        return "Create Mac CheckButton";
    }
}
