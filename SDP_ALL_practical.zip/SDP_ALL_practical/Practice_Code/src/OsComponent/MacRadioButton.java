package OsComponent;

public class MacRadioButton implements RadioButton{
    @Override
    public String createradioButton() {
        return "Create Mac RAdioButton";
    }
}
