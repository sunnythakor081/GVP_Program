public class Cleaning  implements robot{
    public String PerformTask(){
        return "start cleaning";
    }
}
