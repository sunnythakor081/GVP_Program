public interface robot{
 public String PerformTask();
}