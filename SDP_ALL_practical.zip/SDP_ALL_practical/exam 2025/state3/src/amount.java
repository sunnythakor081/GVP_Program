class amount implements bank{

    @Override
    public void setbank(context context) {
      System.out.println("Amount...........!");
      
    }
    
}
