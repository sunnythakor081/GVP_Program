class PIN implements bank{

    @Override
    public void setbank(context context) {
        System.out.println("pin....");
        context.setbihaviar(new amount());
    }
    
}
