interface Observer  {

    void update(String assignment);
}