 class red implements tarafik {

    @Override
    public void tarafiklait(context object) {
    System.out.println("Red on");
    object.soltrafik(new yellow());
    }
    
}
