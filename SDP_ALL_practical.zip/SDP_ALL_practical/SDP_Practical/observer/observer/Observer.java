

interface Observer {
    void update(String news);
}