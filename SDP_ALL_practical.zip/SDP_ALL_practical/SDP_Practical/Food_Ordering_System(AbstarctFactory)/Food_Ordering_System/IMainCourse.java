//package Food_Ordering_System;

interface IMainCourse {
    String OrderMainCourse();
}
