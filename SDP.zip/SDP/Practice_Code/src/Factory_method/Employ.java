package Factory_method;

public interface Employ {
    public int salary();
    public String name();
    public String department();

}
