package Factory_method.Vehicle_Factory;

public interface Vehicle {
    void start();
}
