package Factory_method.Vehicle_Factory;


public class Bike implements Vehicle {

    @Override
    public void start() {
        System.out.println("Bike is starting");
    }
}

