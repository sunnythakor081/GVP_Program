package Facad;

public interface MobileShop {

    public void mobilename();
    public void price();
}
