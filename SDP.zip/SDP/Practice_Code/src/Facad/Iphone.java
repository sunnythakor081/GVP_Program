package Facad;

public class Iphone implements MobileShop {
    @Override
    public void mobilename() {

        System.out.println("iphone 15pro");

    }

    @Override
    public void price() {

        System.out.println("1,30,000");

    }
}
