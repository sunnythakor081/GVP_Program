package Facad;

public class Google_pixel implements MobileShop {
    @Override
    public void mobilename() {

        System.out.println("Google pixel 9");
    }

    @Override
    public void price() {

        System.out.println("90,000");

    }
}
