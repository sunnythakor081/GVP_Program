package state;

public class Client {
    public static void main(String[] args) {
        State state = new State();
        state.checkState();
        state.checkState();
        state.checkState();
        state.checkState();
        state.checkState();
        state.checkState();
        state.checkState();
        state.checkState();
        state.checkState();
        state.checkState();
        state.checkState();
    }
}
