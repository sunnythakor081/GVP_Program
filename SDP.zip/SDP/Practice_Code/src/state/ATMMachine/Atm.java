package state.ATMMachine;

public interface Atm {
    void display(Context state);
}
