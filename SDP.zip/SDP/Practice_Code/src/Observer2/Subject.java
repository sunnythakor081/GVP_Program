package Observer2;

public interface Subject {
    void register(Observ o);
    void removeregister(Observ o);
    void notifyy();
}
