package Observer_Pattern;

public interface Observer {
    void update(String notification);
}
