package Fan_state;

public class Statemain {
    public static void main(String[] args) {
        Fan f = new Fan();
        f.pressButtern();
        f.pressButtern();
    }


}
