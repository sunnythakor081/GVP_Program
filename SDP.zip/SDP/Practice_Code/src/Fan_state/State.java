package Fan_state;

public interface State {
    void pressButtern(Fan fan);
}
