package button;

public abstract class Abstractcom {
    public abstract String radio();
    public abstract String button();
    public abstract String check();
}
