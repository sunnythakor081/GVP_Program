package button;

public class Linux extends Abstractcom {
    @Override
    public String radio() {
        return "linax radio";
    }

    @Override
    public String button() {
        return "linax button";
    }

    @Override
    public String check() {
        return "linax check";
    }
}
