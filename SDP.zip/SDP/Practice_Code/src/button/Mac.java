package button;

public class Mac extends Abstractcom {
    @Override
    public String radio() {
        return "mac radio";
    }

    @Override
    public String button() {
        return "mac button";
    }

    @Override
    public String check() {
        return "mac check";
    }
}
