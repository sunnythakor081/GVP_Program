package vehicle;

public interface Createcar {
    public String color();
    public String speed();
    public String year();
}
