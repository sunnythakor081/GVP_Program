package Strategy;

public interface Snak {
    public String display();
   public String behviyar();
    public void setbehviyar(BiteBehv biteBehv);
}
