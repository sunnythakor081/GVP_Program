package Strategy.paymentMethods;

public interface PymentStrategy {
    void pay(int amount);
}
