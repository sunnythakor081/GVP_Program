package Strategy;

public class Poisonous implements BiteBehv{
    @Override
    public String bite() {
        return "this snak is poisonous";
    }
}
