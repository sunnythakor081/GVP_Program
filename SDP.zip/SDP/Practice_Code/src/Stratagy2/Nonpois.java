package Stratagy2;

public class Nonpois implements Bitebihv{
    @Override
    public String bite() {
        return "";
    }
}
