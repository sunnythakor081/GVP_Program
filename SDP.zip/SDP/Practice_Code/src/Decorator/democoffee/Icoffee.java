package Decorator.democoffee;

public interface Icoffee{
    String getDescription();
    Double getCost();
}
