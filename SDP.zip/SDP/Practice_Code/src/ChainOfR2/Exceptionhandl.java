package ChainOfR2;

public interface Exceptionhandl {
    void sethandler(Exceptionhandl handl);
    void handlException(Exception e);
}
