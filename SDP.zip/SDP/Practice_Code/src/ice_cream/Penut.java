package ice_cream;

public class Penut {
}
