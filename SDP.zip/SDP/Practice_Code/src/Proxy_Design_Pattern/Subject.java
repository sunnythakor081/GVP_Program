package Proxy_Design_Pattern;

public interface Subject {
    void doWrite();
    void doRead();
    void doModify();
}
