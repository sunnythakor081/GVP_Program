package AbStract_factory;

public class GVPpgdca implements Pgdca{
    @Override
    public String createpgdca() {
        return "GVP Pgdca";
    }
}
