package AbStract_factory;

public interface Bca {

    public String createBca();
}
