package AbStract_factory.hospitalABfactory;

public interface Neurology {
    public String createNeurology();
}
