package AbStract_factory.hospitalABfactory;

public class ManipalHospitalCardiology implements Cardiology{
    @Override
    public String createCardiology() {
        return "ManipalHospital Cardiology";
    }
}
