package AbStract_factory.hospitalABfactory;

public class ApolloHospitalsNeurology implements Neurology{
    @Override
    public String createNeurology() {
        return "ApolloHospitals Neurology";
    }
}
