package AbStract_factory;

public class LJpgdca implements Pgdca{
    @Override
    public String createpgdca() {
        return "LJ PGDCA";
    }
}
