package AbStract_factory;

public interface Pgdca {

    public String createpgdca();
}
