package AbStract_factory;

public class ParulMca implements Mca{
    @Override
    public String createMca() {
        return "PARUL MCA";
    }
}
