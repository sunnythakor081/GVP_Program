package AbStract_factory;

public class LJmca implements Mca{
    @Override
    public String createMca() {
        return "LJ MCA";
    }
}
