package AbStract_factory;

public class Parul_Pgdca implements Pgdca{
    @Override
    public String createpgdca() {
        return "PARUL PGDCA";
    }
}
