package client;

public class Linux extends Create_Component {
    @Override
    public String radio() {
        return "linax radiobutton";
    }

    @Override
    public String button() {
        return "linax button";
    }

    @Override
    public String checkbox() {
        return "linax checkbox";
    }
}
