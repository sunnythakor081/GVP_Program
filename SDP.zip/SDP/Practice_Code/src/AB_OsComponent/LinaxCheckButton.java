package AB_OsComponent;

public class LinaxCheckButton implements CheckButton {
    @Override
    public String createcheckButton() {
        return "Create Linax CheckButton";
    }
}
