package AB_OsComponent;

public class LInaxButton implements Button{
    @Override
    public String creactebutton() {
        return "Create Linax Button";
    }
}
