package AB_OsComponent;

public interface CheckButton{
    public String createcheckButton();
}
