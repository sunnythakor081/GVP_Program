package AB_OsComponent;

public interface RadioButton{
    public String createradioButton();
}
