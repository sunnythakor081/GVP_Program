package AB_OsComponent;

public interface Button {
    public  String creactebutton();


}
