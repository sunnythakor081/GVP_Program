interface tarafik {
public void tarafiklait(context object);
    
}