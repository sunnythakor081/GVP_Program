public class App {
    public static void main(String[] args) throws Exception {
        context c=new context();
        c.setbank();
        c.setbank();
        c.setbank();
    }
}
