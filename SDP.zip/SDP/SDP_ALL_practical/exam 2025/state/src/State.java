interface State {
    void pressButton(Fan fan);
}
