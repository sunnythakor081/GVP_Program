

public interface CapsLockState {
    void pressCapsLock(CapsLockContext context);
    char typeKey(char key);
}
