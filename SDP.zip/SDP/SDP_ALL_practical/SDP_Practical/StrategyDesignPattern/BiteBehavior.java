public interface BiteBehavior {
    void bite();
}