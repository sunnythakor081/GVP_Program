//package Food_Ordering_System;

interface IDesserts {
    String OrderDesserts();
}
