//package Food_Ordering_System;

interface IAppetizers {
    String OrderAppetizers();
}
